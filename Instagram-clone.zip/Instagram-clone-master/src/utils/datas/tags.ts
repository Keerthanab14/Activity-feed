const tags = [
    {
        "id": 0,
        "withIcon": true,
        "text": "IGTV"
    },
    {
        "id": 1,
        "withIcon": true,
        "text": "Shop"
    },
    {
        "id": 2,
        "withIcon": false,
        "text": "Style"
    },
    {
        "id": 3,
        "withIcon": true,
        "text": "Decor"
    },
    {
        "id": 4,
        "withIcon": false,
        "text": "Science"
    },
    {
        "id": 5,
        "withIcon": false,
        "text": "Science & Tech"
    },
    {
        "id": 6,
        "withIcon": false,
        "text": "Beauty"
    }
];
export default tags;
