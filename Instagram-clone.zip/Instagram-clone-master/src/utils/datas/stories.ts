const stories = [

    {
        "id": 0,
        "isText": true,
        "avatar": "http://placehold.it/32x32",
        "source": "https://cdn.pixabay.com/photo/2018/11/11/16/51/ibis-3809147__480.jpg",
        "user": "Rutledge Harris"
    },

    {
        "id": 1,
        "isText": false,
        "avatar": "http://placehold.it/32x32",
        "source": "https://cdn.pixabay.com/photo/2018/11/11/16/51/ibis-3809147__480.jpg",
        "user": "Guadalupe Grant"
    },
    {
        "id": 2,
        "isText": false,
        "avatar": "http://placehold.it/32x32",
        "source": "https://picsum.photos/id/202/900/900",
        "user": "Dunlap Sheppard"
    },
    {
        "id": 3,
        "isText": true,
        "avatar": "http://placehold.it/32x32",
        "source": "https://cdn.pixabay.com/photo/2018/11/29/21/19/hamburg-3846525__480.jpg",
        "user": "Bray Oliver"
    },
    {
        "id": 4,
        "isText": true,
        "avatar": "http://placehold.it/32x32",
        "source": "https://picsum.photos/id/208/900/900",
        "user": "Nona Weber"
    },
    {
        "id": 5,
        "isText": true,
        "avatar": "http://placehold.it/32x32",
        "source": "https://picsum.photos/id/220/900/900",
        "user": "Freida Mann"
    }
];
export default stories;
