import React from 'react'
const AuxHOC = (props:any) => props.children;
export default AuxHOC;
