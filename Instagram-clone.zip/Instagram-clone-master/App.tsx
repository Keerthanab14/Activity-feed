import React from 'react';
import AppNavigator from "./src/navigation/navigation";

const App = () => {
  console.disableYellowBox = true;
  return (
      <AppNavigator/>
  );
};

export default App;
