const follows = [
    {
        "id": 0,
        "type": "following",
        "text": "@Pachel started following you",
        "time": "1w",
        "avatar":require('~/assets/images/post1.png'),
        "category":"week"


    },
    {
        "id": 1,
        "type": "follow",
        "text": "@cedvit and @Melvich followed @Pavel on instagram. see their post",
        "time": "2w",
        "avatar":require('~/assets/images/post2.png'),
        "category":"week"
    },
    {
        "id": 2,
        "type": "other",
        "text": "Follow @Eric and @Bill to watch their photos and videos",
        "time": "3w",
        "avatar":require('~/assets/images/post3.png')
    },
    {
        "id": 3,
        "type": "other",
        "text": "Follow @GTCx , @Fsys_mi and @Polyc to watch their photos and videos",
        "time": "3w",
        "avatar":require('~/assets/images/post4.png'),
        "category":"week"
    },
    {
        "id": 4,
        "type": "follow",
        "text": "Follow @Eric and @Bill to watch their photos and videos",
        "time": "3w",
        "avatar":require('~/assets/images/post5.png'),
        "category":"month"
    },
    {
        "id": 5,
        "type": "follow",
        "text": "Follow @GTCx , @Fsys_mi and @Polyc to watch their photos and videos",
        "time": "3w",
        "avatar":require('~/assets/images/post6.png'),
        "category":"month"
    },

    //

    {
        "id": 6,
        "type": "follow",
        "text": "Follow @Eric and @Bill to watch their photos and videos",
        "time": "3w",
        "avatar":require('~/assets/images/post3.png'),
        "category":"month"
    },
    {
        "id": 7,
        "type": "following",
        "text": "Follow @GTCx , @Fsys_mi and @Polyc to watch their photos and videos",
        "time": "3w",
        "avatar":require('~/assets/images/post4.png'),
        "category":"month"
    },
    {
        "id": 8,
        "type": "other",
        "text": "Follow @Eric and @Bill to watch their photos and videos",
        "time": "3w",
        "avatar":require('~/assets/images/post5.png'),
        "category":"early"
    },
    {
        "id": 9,
        "type": "follow",
        "text": "Follow @GTCx , @Fsys_mi and @Polyc to watch their photos and videos",
        "time": "3w",
        "avatar":require('~/assets/images/post6.png'),
        "category":"early"
    },
    {
        "id": 8,
        "type": "other",
        "text": "Follow @Eric and @Bill to watch their photos and videos",
        "time": "3w",
        "avatar":require('~/assets/images/post5.png'),
        "category":"early"
    },
    {
        "id": 9,
        "type": "other",
        "text": "Follow @GTCx , @Fsys_mi and @Polyc to watch their photos and videos",
        "time": "3w",
        "avatar":require('~/assets/images/post6.png'),
        "category":"early"
    },


    //:xx

    {
        "id": 10,
        "type": "following",
        "text": "@Pachel started following you",
        "time": "1w",
        "avatar":require('~/assets/images/post1.png'),
        "category":"week"


    },
    {
        "id": 11,
        "type": "follow",
        "text": "@cedvit and @Melvich followed @Pavel on instagram. see their post",
        "time": "2w",
        "avatar":require('~/assets/images/post2.png'),
        "category":"week"
    },
    {
        "id": 12,
        "type": "other",
        "text": "Follow @Eric and @Bill to watch their photos and videos",
        "time": "3w",
        "avatar":require('~/assets/images/post3.png')
    },
    {
        "id": 13,
        "type": "other",
        "text": "Follow @GTCx , @Fsys_mi and @Polyc to watch their photos and videos",
        "time": "3w",
        "avatar":require('~/assets/images/post4.png'),
        "category":"week"
    },
    {
        "id": 14,
        "type": "follow",
        "text": "Follow @Eric and @Bill to watch their photos and videos",
        "time": "3w",
        "avatar":require('~/assets/images/post5.png'),
        "category":"month"
    },
    {
        "id": 15,
        "type": "follow",
        "text": "Follow @GTCx , @Fsys_mi and @Polyc to watch their photos and videos",
        "time": "3w",
        "avatar":require('~/assets/images/post6.png'),
        "category":"month"
    },

    //

    {
        "id": 16,
        "type": "follow",
        "text": "Follow @Eric and @Bill to watch their photos and videos",
        "time": "3w",
        "avatar":require('~/assets/images/post3.png'),
        "category":"month"
    },
];
export default follows;
