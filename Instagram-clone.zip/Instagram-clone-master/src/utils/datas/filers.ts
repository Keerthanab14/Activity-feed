const filter = [
    {id: 0, name: "Live"},
    {id: 1, name: "Create"},
    {id: 2, name: "Normal"},
    {id: 3, name: "Boomerang"},
    {id: 4, name: "Superzoom"},
    {id: 5, name: "Hands-free"}
];
export default filter;
