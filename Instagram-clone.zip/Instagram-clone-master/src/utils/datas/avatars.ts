const avatars: Array<any> = [
    {
        id: 0,
        live: false,
        name: "Your story",
        src: require('~/assets/images/ic1.png')
    },
    {
        id: 1,
        live: true,
        name: "Cheppard",
        src: require('~/assets/images/ic1.png')
    },
    {
        id: 2,
        live: false,
        name: "Duke",
        src: require('~/assets/images/ic2.png')
    },
    {
        id: 3,
        live: false,
        name: "Pavel",
        src: require('~/assets/images/ic3.png')
    },
    {
        id: 4,
        live: false,
        name: "Steeve",
        src: require('~/assets/images/ic4.png')
    },
    {
        id: 5,
        live: false,
        name: "Reenessis",
        src: require('~/assets/images/ic5.png')
    },
    {
        id: 6,
        live: false,
        name: "Aria",
        src: require('~/assets/images/ic6.png')
    },
    {
        id: 7,
        live: false,
        name: "Tyrion",
        src: require('~/assets/images/ic7.png')
    },
];
export default avatars;
