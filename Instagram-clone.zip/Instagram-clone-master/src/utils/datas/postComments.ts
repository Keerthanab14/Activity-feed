const PostComments : Array<any> = [
    {id:0,avatar:true,canReply:true, author:"Davila Ruise",message:`❤️ I miss you honney. keep working✨`},
    {id:1,avatar:true,canReply:false, author:"Jenny Scofield",message:`Hi sir , can you please suggest me some ressourses please :)`},
    {id:2,avatar:true,canReply:false, author:"Abela Menson",message:`Lol. Instagram is a very great app. Keep moving and learning huys`},
    {id:3,avatar:true,canReply:false, author:"Daniel Jee",message:`Hi. I'm new here, where to start ? can i found some friends here , please ?`},
    {id:4,avatar:true,canReply:true, author:"Davila Ruise",message:`❤️ I miss you honney. keep working✨`},
    {id:5,avatar:true,canReply:false, author:"Jenny Scofield",message:`Hi sir , can you please suggest me some ressourses please :)`},
    {id:6,avatar:true,canReply:false, author:"Abela Menson",message:`Lol. Instagram is a very great app. Keep moving and learning huys`},
    {id:7,avatar:true,canReply:false, author:"Daniel Jee",message:`Hi. I'm new here, where to start ? can i found some friends here , please ?`}
];
export default PostComments;
